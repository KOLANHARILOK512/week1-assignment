module observerpattern {
}